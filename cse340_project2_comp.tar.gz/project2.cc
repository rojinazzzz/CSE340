/*
 * Copyright (C) Mohsen Zohrevandi, 2017
 *
 * Do not share this file with anyone
 */
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include <list>
#include <string.h>

#include "lexer.h"

using namespace std;

struct rule;
void ro(LexicalAnalyzer &lexer);
int main (int argc, char* argv[])
{
    int task;
    string s;
    if (argc < 2)
    {
        cout << "Error: missing argument\n";
        return 1;
    }

    /*
       Note that by convention argv[0] is the name of your executable,
       and the first argument to your program is stored in argv[1]
     */

    task = atoi(argv[1]);

    // TODO: Read the input grammar at this point from standard input

    /*
       Hint: You can modify and use the lexer from previous project
       to read the input. Note that there are only 4 token types needed
       for reading the input in this project.

       WARNING: You will need to modify lexer.cc and lexer.h to only
       support the tokens needed for this project if you are going to
       use the lexer.
     */
    LexicalAnalyzer lexer;
    
    
    switch (task) {
        case 1:
            // TODO: perform task 1.
            ro(lexer);
            break;

        case 2:
            // TODO: perform task 2.
            break;

        case 3:
            // TODO: perform task 3.
            break;

        case 4:
            // TODO: perform task 4.
            break;

        case 5:
            // TODO: perform task 5.
            break;

        default:
            cout << "Error: unrecognized task number " << task << "\n";
            break;
    }
    return 0;
}

struct rule{
   string LHS;
   vector<string> RHS;
};


void ro(LexicalAnalyzer &lexer){
    vector<string> non_terminal;
      vector<string> terminal ;
    Token t;
    t = lexer.GetToken();
     
     vector<rule> grammar; 
     
    
    //iterate through grammar
    while((t.token_type) != DOUBLEHASH){
       rule n;
            n.LHS = t.lexeme;
            
            if(non_terminal.empty())
            {
                    non_terminal.push_back(n.LHS);
                    
            }
            else 
            {
               // for(int i =0; i < non_terminal.size(); i++){
                    if(non_terminal.back().compare(n.LHS) != 0){
                    non_terminal.push_back(n.LHS);
                    
                    }
                    for(int i =0; i < non_terminal.size(); i++){
                    cout << "none terminal is" << non_terminal[i] << endl;
                    }
                 //}
            }
            t = lexer.GetToken();
            if((t.token_type) == ARROW){
                t = lexer.GetToken();
            
      
                while(t.token_type != HASH){

                    n.RHS.push_back(t.lexeme);
                    cout << t.lexeme << " is pushed back" << endl;
                    t  = lexer.GetToken();
                }         
            }
        grammar.push_back(n);
        n.RHS.clear();
        t = lexer.GetToken();
        
    } 
     for ( int i = 0; i < grammar.size(); i++){
        cout << grammar.at(i).LHS << " -> ";
        for(int j = 0; j <grammar.at(i).RHS.size(); j++){
            cout << grammar.at(i).RHS.at(j)<< " ";
        }
        cout << endl;    
    }
     
     cout << grammar.at(0).RHS.at(0) << endl;
        
     for(int i =0; i < grammar.size(); i++)
     {
         cout<< "sergio1" << endl;
         cout << grammar.at(i).RHS.at(0) << endl;
         for(int j = 0; j < grammar.at(i).RHS.size(); j++)
         {
             cout<< "sergio2" << endl;
             for(int k = 0; k < non_terminal.size(); k++)
             {
                 cout<< "sergio3" << endl;
               if(non_terminal.at(i).compare(grammar.at(i).RHS.at(j))!= 0)
               {
                   
                   terminal.push_back(grammar.at(i).RHS.at(j));
                    cout<< "sergio4" << endl;
                }
                 
             }
         }
     }
     
     cout << "the list of terminals are ";
     for(int i = 0; i < terminal.size(); i++)
     {
         cout << terminal[i] << " ";
         
     }
     cout << endl;
     for(int i = 0; i = terminal.size(); i++){
         cout<< terminal[i] << endl;
     }/*
   * 
   * 
   * 
   * /
     
   * 
   * 
       
        for (iterator2 = grammar.begin(); iterator2 != grammar.end(); ++iterator2) {//vector<string>::iterator it2;
              //if 
               RHS_array[count2] = iterator2->RHS;
               count2++;
           }
        int size1 =0;
        string nont_array [size1];
        
        int size2 =0;
        string t_array [size2];
        for(int i =0 ; i = LHS_array->size()-1; i++){
            for( int j = 0; RHS_array->size(); j++){
                if (strcmp(LHS_array[i], RHS_array[j]) != 0){
                    t_array->append(LHS_array[i]);
                    size2 ++;
                    
                }
                else{
                    nont_array->append(LHS_array[i]);
                    size1 ++;
                }
            }
            
        }
        
     */   
   
        
    
  /*   for ( int i = 0; i < grammar.size(); i++){
        cout << grammar.at(i).LHS << " -> ";
        for(int j = 0; j <grammar.at(i).RHS.size(); j++){
            cout << grammar.at(i).RHS.at(j)<< " ";
        }
        cout << endl;    
    }
*/

}
